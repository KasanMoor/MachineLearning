class MyMatrix: matrix
{
}
